#if !defined(NULL)
#define NULL 0
#endif

typedef struct queue QUEUE;

QUEUE *new_queue();

int size(QUEUE *);

void free_queue(QUEUE *);

void enqueue(QUEUE *, void *);

void *dequeue(QUEUE *);
